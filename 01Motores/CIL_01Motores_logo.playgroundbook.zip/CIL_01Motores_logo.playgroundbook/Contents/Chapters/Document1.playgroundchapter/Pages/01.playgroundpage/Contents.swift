//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
  Para aprender las distintas instrucciones y funciones que vamos a usar, utilizaremos el *Robot Educador* un excelente punto de referencia para conocer los elementos y sensores del EV3.


  ### Construye el *Robot Educador*

  ![DrivingBase](driving-base-page1.jpg)

  ![DrivingBase](driving-base-page2.jpg)

  ![DrivingBase](driving-base-page3.jpg)

  ![DrivingBase](driving-base-page4.jpg)

 ![DrivingBase](driving-base-page5.jpg)

 ![DrivingBase](driving-base-page6.jpg)

 ![DrivingBase](driving-base-page7.jpg)

 ![DrivingBase](driving-base-page8.jpg)

 ![DrivingBase](driving-base-page9.jpg)

 ![DrivingBase](driving-base-page10.jpg)

 ![DrivingBase](driving-base-page11.jpg)

 ![DrivingBase](driving-base-page12.jpg)

 ![DrivingBase](driving-base-page13.jpg)

 ![DrivingBase](driving-base-page14.jpg)

 ![DrivingBase](driving-base-page15.jpg)

 ![DrivingBase](driving-base-page16.jpg)

 ![DrivingBase](driving-base-page17.jpg)

 ![DrivingBase](driving-base-page18.jpg)

 ![DrivingBase](driving-base-page19.jpg)

 ![DrivingBase](driving-base-page20.jpg)

 ![DrivingBase](driving-base-page21.jpg)

 ![DrivingBase](driving-base-page22.jpg)

 ![DrivingBase](driving-base-page23.jpg)

 ![DrivingBase](driving-base-page24.jpg)

 ![DrivingBase](driving-base-page25.jpg)

 ![DrivingBase](driving-base-page26.jpg)

 ![DrivingBase](driving-base-page27.jpg)

 ![DrivingBase](driving-base-page28.jpg)
 
 ![DrivingBase](driving-base-page29.jpg)

 ![DrivingBase](driving-base-page30.jpg)

 ![DrivingBase](driving-base-page31.jpg)
 
 ![DrivingBase](driving-base-page32.jpg)
 
 ![DrivingBase](driving-base-page33.jpg)
 
 ![DrivingBase](driving-base-page34.jpg)
 
 ![DrivingBase](driving-base-page35.jpg)
 
 ![DrivingBase](driving-base-page36.jpg)
 
 ![DrivingBase](driving-base-page37.jpg)
 
 ![DrivingBase](driving-base-page38.jpg)
 
 ![DrivingBase](driving-base-page39.jpg)
 
 ![DrivingBase](driving-base-page40.jpg)
 
 ![DrivingBase](driving-base-page41.jpg)
 
 ![DrivingBase](driving-base-page42.jpg)
 
 ![DrivingBase](driving-base-page43.jpg)
 
 ![DrivingBase](driving-base-page44.jpg)
 
 ![DrivingBase](driving-base-page45.jpg)
 
 ![DrivingBase](driving-base-page46.jpg)

  */
