//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
  Antes de comenzar un proyecto nuevo, debes conectar tu [Bloque EV3](glossary://EV3%20Brick) a tu iPad.
 
  Para hacerlo, sigue estos pasos:

  1.  Toca *Conectar Bloque EV3*.
  2.  Una vez que el bloque EV3 se haya enlazado con tu iPad, la [visualización de puertos](glossary://Port%20View) te mostrará cada valor de cualquier [entrada](glossary://Input) o [salida](glossary://Output) que esté conectada a un puerto.

  -   Callout(Icono de la visualización de puertos): ![Port View](live_view_plates_mode@2x.png)

  ### Programa
 
  Toca *Ejecutar mi código* para enviar tu primer programa y hacer que el Bloque EV3 diga "Hello".
 
  Puedes cambiar el volumen modificando el valor "100".

 Una vez que lo logres, pasa a la siguiente página.
  */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, ev3, .)
//#-code-completion(identifier, show, playSound(file:atVolume:withStyle:))
//#-code-completion(identifier, show, SoundFile, hello, goodbye, fanfare, errorAlarm, start, stop, object, ouch, blip, arm, snap, laser)
//#-code-completion(identifier, show, SoundStyle, waitForCompletion, playOnce, playRepeat)
ev3.playSound(
    file: .hello,
    atVolume: /*#-editable-code*/100.00/*#-end-editable-code*/,
    withStyle: .playOnce)

