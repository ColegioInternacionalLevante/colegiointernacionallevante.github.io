import PlaygroundSupport

let viewController: PlatesViewController = PlatesViewController.instantiateFromMainStoryboard()
PlaygroundPage.current.liveView = viewController
