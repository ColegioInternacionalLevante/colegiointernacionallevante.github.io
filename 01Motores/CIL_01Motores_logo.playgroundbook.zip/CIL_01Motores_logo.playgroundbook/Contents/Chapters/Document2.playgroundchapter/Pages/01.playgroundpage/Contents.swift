//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
  Una vez conectado tu *Bloque EV3* vamos a aprender a moverlo.
 
 ### Pruébalo
  Ejecuta el código que hay a continuación y observa lo que pasa.

- Important: Modifica los puertos `leftPort` y `rightPort` con los de tu montaje

 ### Modifícalo
 
  1.  Agrega tu propio código con el mismo comando
  2.  Cambia la duración y la potencia y observa como varía la distancia recorrida.

  */ 
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, ev3, .)
//#-code-completion(identifier, show, move(forSeconds:leftPort:rightPort:leftPower:rightPower:))
//#-code-completion(identifier, show, Outputport, a, b, c, d)
//#-code-completion(identifier, show, OutputPort, a, b, c, d)
ev3.move(forSeconds: 2, leftPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, rightPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, leftPower: 40, rightPower: 40)
//#-editable-code

//#-end-editable-code
