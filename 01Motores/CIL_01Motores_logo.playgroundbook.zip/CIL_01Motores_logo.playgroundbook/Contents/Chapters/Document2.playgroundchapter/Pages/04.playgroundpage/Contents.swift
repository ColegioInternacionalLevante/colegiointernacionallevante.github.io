//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 Como objeto para mover vamos a usar el *CuboId*, podemos usar cualquier otro objeto que tenga las medidas y peso adecuados.
 
 ### Construye
 
 Sigue las instrucciones para montar el *CuboId*
 
 ![Cuboid](Cuboid-01.jpg)
 ![Cuboid](Cuboid-02.jpg)
 ![Cuboid](Cuboid-03.jpg)
 ![Cuboid](Cuboid-04.jpg)
 ![Cuboid](Cuboid-05.jpg)
 ![Cuboid](Cuboid-06.jpg)
 ![Cuboid](Cuboid-07.jpg)
 */
