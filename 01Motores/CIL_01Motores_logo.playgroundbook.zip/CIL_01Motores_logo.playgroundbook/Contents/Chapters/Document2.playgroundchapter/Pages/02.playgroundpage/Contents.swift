//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
  Ahora que ya sabemos mover nuestro robot en línea recta, vamos a aprender a realizar movimientos en curva.
  En el siguiente vídeo podemos ver los 3 tipos de curvas que se pueden realizar con el EV3
  ![Curved_Move](CurvedMove.mp4)
 
 ### Pruébalo
  Ejecuta el código que hay a continuación y observa lo que pasa.
 *La función waitFor() nos crea una pausa por el tiempo especificado.

- Important: Modifica los puertos `leftPort` y `rightPort` con los de tu montaje

 ### Modifícalo
 
  1.  Agrega tu propio código.
  2.  Modifica los valores para ver las distintas opciones.

  */ 
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, ev3, .)
//#-code-completion(identifier, show, move(forRotations:leftPort:rightPort:leftPower:rightPower:))
//#-code-completion(identifier, show, Outputport, a, b, c, d)
//#-code-completion(identifier, show, OutputPort, a, b, c, d)
//#-code-completion(identifier, show, waitFor(seconds:))
ev3.move(forRotations: 2, leftPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, rightPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, leftPower: 40, rightPower: 40)
ev3.waitFor(seconds:/*#-editable-code*/1.0/*#-end-editable-code*/)
ev3.move(forRotations: 4, leftPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, rightPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, leftPower: 40, rightPower: 0)
ev3.waitFor(seconds:/*#-editable-code*/1.0/*#-end-editable-code*/)
ev3.move(forRotations: 4, leftPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, rightPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, leftPower: 40, rightPower: 10)
//#-editable-code

//#-end-editable-code
