//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 Para poder mover objetos nuestro robot necesita otro motor, en este caso usaremos el [Motor Mediano](glossary://Motor%20(Medium))

  ### Construye el Motor Mediano

  Si tu no tienes un [Motor Mediano](glossary://Motor%20(Medium)) conectado a tu EV3, construyelo siguiendo son las instruciones siguientes.

  ![MediumMotor](MediumMotor-01.jpg)
  ![MediumMotor](MediumMotor-02.jpg)
  ![MediumMotor](MediumMotor-03.jpg)
  ![MediumMotor](MediumMotor-04.jpg)
  ![MediumMotor](MediumMotor-05.jpg)
  ![MediumMotor](MediumMotor-06.jpg)
  ![MediumMotor](MediumMotor-07.jpg)
  ![MediumMotor](MediumMotor-08.jpg)
  ![MediumMotor](MediumMotor-09.jpg)
  ![MediumMotor](MediumMotor-10.jpg)
 ![MediumMotor](MediumMotor-11.jpg)
 ![MediumMotor](MediumMotor-12.jpg)
 ![MediumMotor](MediumMotor-13.jpg)
 ![MediumMotor](MediumMotor-14.jpg)
 ![MediumMotor](MediumMotor-15.jpg)
 ![MediumMotor](MediumMotor-16.jpg)
 ![MediumMotor](MediumMotor-17.jpg)
 ![MediumMotor](MediumMotor-18.jpg)
 ![MediumMotor](MediumMotor-19.jpg)
 ![MediumMotor](MediumMotor-20.jpg)
 ![MediumMotor](MediumMotor-21.jpg)
  */
