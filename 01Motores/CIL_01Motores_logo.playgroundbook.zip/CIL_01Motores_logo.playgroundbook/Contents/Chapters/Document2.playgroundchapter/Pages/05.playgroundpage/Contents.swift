//#-hidden-code
import PlaygroundSupport
import Foundation

let ev3 = PlaygroundPageSupport.createRobot()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
  Con nuestro modelo ampliado vamos a ver la posibilidad de poder mover un objeto según se muestra en el siguiente vídeo.
  ![MoveObject](moveObject.mp4)
 
 ### Pruébalo
  Ejecuta el código que hay a continuación y observa lo que pasa. Comprueba que el motor mediano está en posición vertical.

- Important: Modifica los puertos `leftPort` y `rightPort` con los de tu montaje.

 ### Modifícalo
 
  1.  Modifica el código para mover el objeto por distintos puntos.
  2.  Agrega más código para desplazar el objeto de un lugar a otro.

  */ 
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(literal, show, integer, float)
//#-code-completion(identifier, show, ev3, .)
//#-code-completion(identifier, show, motorOn(forRotations:on:withPower:breakAtEnd))
//#-code-completion(identifier, show, Outputport, a, b, c, d)
//#-code-completion(identifier, show, Bool, true, false)
//#-code-completion(identifier, show, move(forRotations:leftPort:rightPort:leftPower:rightPower:))
//#-code-completion(identifier, show, Outputport, a, b, c, d)
ev3.motorOn(forRotations: 0.5, on: /*#-editable-code*/<#OutputPort#>/*#-end-editable-code*/, withPower: -30, brakeAtEnd: true)
ev3.move(forRotations: 2, leftPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, rightPort:/*#-editable-code*/<#T##OutputPort#>/*#-end-editable-code*/, leftPower: 40, rightPower: 40)
ev3.motorOn(forRotations: 0.5, on: /*#-editable-code*/<#OutputPort#>/*#-end-editable-code*/, withPower: 30, brakeAtEnd: true)
//#-editable-code

//#-end-editable-code
