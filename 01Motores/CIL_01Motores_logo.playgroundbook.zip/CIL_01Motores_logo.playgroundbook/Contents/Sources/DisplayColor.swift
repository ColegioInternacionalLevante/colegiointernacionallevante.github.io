//
//  DisplayColor.swift
//  PlaygroundContent
//

public enum DisplayColor: UInt8 {
    case white = 0
    case black = 1
}

