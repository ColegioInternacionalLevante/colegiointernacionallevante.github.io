import UIKit

extension PlateGridViewLayout {
    func prepareEmptyLayout() {
        // Nothing to do for an empty layout
    }
}
