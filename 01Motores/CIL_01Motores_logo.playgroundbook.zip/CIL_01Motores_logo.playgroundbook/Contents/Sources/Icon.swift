//
//  Icon.swift
//  PlaygroundContent
//

public enum Icon: UInt8 { // TODO: also must be fleshed out
    case smile
    case eyes
}
