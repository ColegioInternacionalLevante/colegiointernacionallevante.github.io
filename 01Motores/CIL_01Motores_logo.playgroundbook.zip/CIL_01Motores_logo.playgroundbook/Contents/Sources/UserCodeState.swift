import Foundation

enum UserCodeState {
    case ready
    case running
    case finished
}
