//
//  DisplayFont.swift
//  PlaygroundContent
//

public enum DisplayFont: UInt8 {
    case normal = 0
    case bold = 1
    case large = 2
}
