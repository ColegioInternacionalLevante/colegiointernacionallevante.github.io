public enum SoundStyle {
    case waitForCompletion
    case playOnce
    case playRepeat
}
