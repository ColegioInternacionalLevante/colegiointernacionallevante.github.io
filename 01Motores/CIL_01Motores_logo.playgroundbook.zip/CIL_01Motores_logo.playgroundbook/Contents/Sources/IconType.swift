//
//  IconType.swift
//  PlaygroundContent
//

public enum IconType: UInt8 { // TODO: get the internal list of icon types
    case a = 0
    case b = 1
}
